# sign_lang_detection > 2024-11-27 11:11pm
https://universe.roboflow.com/piyushchaubeyworks/sign_lang_detection

Provided by a Roboflow user
License: CC BY 4.0

